new Vue({
  el: "#denomination",
  data: {
    netTotal: " ",
    cash: " ",
    change: 0,
    remain: 0,
    remainThousand: 0,
    remainFiveHundred: 0,
    remainHundred: 0,
    remainFifty: 0,
    remainTwenty: 0,
    remainTen: 0,
    remainFive: 0,
    remainOne: 0,
    cThousand: 0,
    cFivehundred: 0,
    cHundred: 0,
    cFifty: 0,
    cTwenty: 0,
    cTen: 0,
    cFive: 0,
    cOne: 0,
    cFifty_cent:0,
    cTwenty_cent:0,
    cTen_cent:0,
    cFive_cent:0,
    cTwo_cent:0,
    cOne_cent:0,
    
  },
  methods: {
    calculate: function () {
      var self = this;
      self.change = parseFloat(self.cash - self.netTotal).toFixed(2);
      self.cThousand = parseInt(self.change / 1000);
      self.remain = self.change - 1000 * self.cThousand;
      if (self.remain >= 500) {
        self.cFivehundred = parseInt(self.remain / 500);
        self.remain = self.remain - 500 * self.cFivehundred;
      }
      if (self.remain >= 100) {
        self.cHundred = parseInt(self.remain / 100);
        self.remain = self.remain - 100 * self.cHundred;
      }
      if (self.remain >= 50) {
        self.cFifty = parseInt(self.remain / 50);
        self.remain = self.remain - 50 * self.cFifty;
      }
      if (self.remain >= 20) {
        self.cTwenty = parseInt(self.remain / 20);
        self.remain = self.remain - 20 * self.cTwenty;
      }
      if (self.remain >= 10) {
        self.cTen = parseInt(self.remain / 10);
        self.remain = self.remain - 10 * self.cTen;
      }
      if (self.remain >= 5) {
        self.cFive = parseInt(self.remain / 5);
        self.remain = self.remain - 5 * self.cFive;
      }
      if (self.remain >= 1) {
        self.cOne = parseInt(self.remain / 1);
        self.remain = self.remain - 1 * self.cOne;
      }
      if (self.remain >= 0.5) {
        self.cFifty_cent = parseInt(self.remain / 0.5);
        self.remain = self.remain - 0.5 * self.cFifty_cent;
      }
      if (self.remain >= 0.2) {
        self.cTwenty_cent = parseInt(self.remain / 0.2);
        self.remain = self.remain - 0.2 * self.cTwenty_cent;
      }
      if (self.remain >= 0.1) {
        self.cTen_cent = parseInt(self.remain / 0.1);
        self.remain = self.remain - 0.1 * self.cTen_cent;
      }
      if (self.remain >= 0.05) {
        self.cFive_cent = parseInt(self.remain / 0.05);
        self.remain = self.remain - 0.05 * self.cFive_cent;
      }
      if (self.remain >= 0.02) {
        self.cTwo_cent = parseInt(self.remain / 0.02);
        self.remain = self.remain - 0.02 * self.cTwo_cent;
      }
      if (self.remain >= 0.01) {
        self.cOne_cent = parseInt(self.remain / 0.01);
        self.remain = self.remain - 0.01 * self.One_cent;
      }
     
      
    },
    reset: function () {
      this.netTotal = null;
      this.cash = null;
      this.change = null;
      this.cThousand = 0;
      this.cFivehundred = 0;
      this.cHundred = 0;
      this.cFifty = 0;
      this.cTwenty = 0;
      this.cTen = 0;
      this.cFive = 0;
      this.cOne = 0;
      this.cFifty_cent = 0;
      this.cTwenty_cent = 0;
      this.cTen_cent = 0;
      this.cFive_cent = 0;
      this.cTwo_cent = 0;
      this.cOne_cent = 0;
      
    }
  }
});
