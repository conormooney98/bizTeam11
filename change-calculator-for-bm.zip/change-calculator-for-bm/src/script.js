function processEntries() {
   var Euro = document.getElementById("Euro").value;
   if(Euro >=0){
makeChange(Euro);
   } 
   else{
       alert("vale should be between 0 and 1000000");
document.getElementById("fifty_euro").value = "";
document.getElementById("twenty_euro").value = "";
document.getElementById("ten_euro").value = "";
document.getElementById("five_euro").value = ""; 
document.getElementById("two_euro").value = "";
document.getElementById("one_euro").value = ""; 
document.getElementById("fifty").value = "";       document.getElementById("twenty").value = "";
document.getElementById("ten").value = "";
document.getElementById("five").value = "";
document.getElementById("two").value = "";
document.getElementById("penny").value = "";
   } 
}

function makeChange (Euro) {
   var fifty_euro = parseInt(Euro / 50);
   Euro = Euro % 50;
   var twenty_euro = parseInt(Euro / 20);
   Euro = Euro % 20;
   var ten_euro = parseInt(Euro / 10);
   Euro = Euro % 10;
   var five_euro = parseInt(Euro / 5);
   Euro = Euro % 5;
   var two_euro = parseInt(Euro / 2);
   Euro = Euro % 2;
   var one_euro = parseInt(Euro / 1);
   Euro = Euro % 1;
   var fifty = parseInt(Euro / 0.5);
   Euro = Euro % 0.5;
   var twenty = parseInt(Euro / 0.2);
   Euro = Euro % 0.2;
   var ten = parseInt(Euro / 0.1);
       Euro = Euro % 0.1;
   var five = parseInt(Euro / 0.05);
       Euro = Euro % 0.05;
  var two = parseInt(Euro / 0.02);
       Euro = Euro % 0.02;
   var penny = parseInt(Euro / 0.01);
document.getElementById("fifty_euro").value = fifty_euro;
document.getElementById("twenty_euro").value = twenty_euro;
document.getElementById("ten_euro").value = ten_euro;
document.getElementById("five_euro").value = five_euro;
document.getElementById("two_euro").value = two_euro;
document.getElementById("one_euro").value = one_euro;
document.getElementById("fifty").value = fifty;
document.getElementById("twenty").value = twenty;
document.getElementById("ten").value = ten;
document.getElementById("five").value = five;
document.getElementById("two").value = two;
document.getElementById("penny").value = penny;
} 
